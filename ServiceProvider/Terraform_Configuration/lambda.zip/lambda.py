import boto3
import datetime

# AWS region and EC2 instance ID
region = 'us-east-1'
instance_id = ['i-023d7fe877380659b'] 

# Assume role in other account
sts_client = boto3.client('sts')
assumed_role = sts_client.assume_role(
    RoleArn='arn:aws:iam::307159671411:role/lambdarole',
    RoleSessionName='EC2SchedulerSession'
)

# Create EC2 client with assumed role credentials
ec2 = boto3.client('ec2',
    aws_access_key_id=assumed_role['Credentials']['AccessKeyId'],
    aws_secret_access_key=assumed_role['Credentials']['SecretAccessKey'],
    aws_session_token=assumed_role['Credentials']['SessionToken'],
    region_name=region
)

def lambda_handler(event, context):
    # Get the current UTC time each time the function runs
    current_time = datetime.datetime.now(datetime.timezone.utc)
    current_hour = current_time.hour

    # Define work hours in UTC
    WORK_START_HOUR = 8  # 8 AM UTC (Start work)
    WORK_END_HOUR = 22  # 10 PM UTC (Stop work) 

    if WORK_START_HOUR <= current_hour < WORK_END_HOUR:
        action = "start"
    else:
        action = "stop"

    print(f"Current UTC time: {current_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Determined action: {action.upper()} for EC2 instance {instance_id}")

    if action == "stop":
        ec2.stop_instances(InstanceIds=instance_id)
        print("EC2 instance stopped.")
    elif action == "start":
        ec2.start_instances(InstanceIds=instance_id)
        print("EC2 instance started.")

    return {
        "status": "Success",
        "action": action
    }
